from pybricks.tools import hub_menu
from cls_Main import MissionRobot

robot = MissionRobot() 

import opendoor
import exploringseeds

missions = {"1": opendoor.run, "2": exploringseeds.run}

while True:
    selected = hub_menu(*missions.keys())
    missions[selected](robot)
    # opendoor.run(robot)