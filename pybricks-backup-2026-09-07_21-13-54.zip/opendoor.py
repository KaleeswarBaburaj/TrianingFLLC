
def run(robot):
    #robot.move_robot(200,200,150)
    robot.reset_heading()
    robot.move_robot(200)
    robot.turn_to_heading(-45)

    #robot.run_left_attachment(360,500,False)
    #robot.run_right_attachment(-180,600, False)
    # robot.stop_at_black_line(black_threshold=25)
    
    # self.hub.imu.heading()          # read current heading (degrees, float)
    # self.hub.imu.reset_heading(0)   # set current heading to be "0"
    # robot.gyro_turn(90)
    # robot.gyro_straight(50)


